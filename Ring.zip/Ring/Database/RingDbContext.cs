using System;
using Microsoft.EntityFrameworkCore;
using Ring.Models;

namespace Ring.Database
{
    public class RingDbContext : DbContext
    {
        public RingDbContext(DbContextOptions<RingDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Alarm> Alarms { get; set; }
        public DbSet<Batch> Batches { get; set; }
        public DbSet<Tank> Tanks { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // User configuration
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Username).IsRequired().HasMaxLength(50);
                entity.Property(e => e.PasswordHash).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Level).IsRequired();
                entity.Property(e => e.SystemNumber).IsRequired();
                entity.Property(e => e.UserNumber).IsRequired();
                entity.Property(e => e.FullName).HasMaxLength(100);
                entity.Property(e => e.Email).HasMaxLength(200);
                entity.Property(e => e.IsEnabled).IsRequired();
                entity.Property(e => e.IsLocked).IsRequired();
                entity.Property(e => e.CreatedAt).IsRequired();
                
                // Indexes
                entity.HasIndex(e => e.Username).IsUnique();
                entity.HasIndex(e => e.SystemNumber);
            });

            // Alarm configuration
            modelBuilder.Entity<Alarm>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.TagName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Description).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Priority).IsRequired();
                entity.Property(e => e.Type).IsRequired();
                entity.Property(e => e.Status).IsRequired();
                entity.Property(e => e.CreatedAt).IsRequired();
                entity.Property(e => e.AcknowledgedByUserName).HasMaxLength(50);
                entity.Property(e => e.Value).HasMaxLength(100);
                entity.Property(e => e.Setpoint).HasMaxLength(100);
                entity.Property(e => e.Units).HasMaxLength(100);
                entity.Property(e => e.AdditionalInfo).HasMaxLength(500);
                
                // Indexes
                entity.HasIndex(e => e.TagName);
                entity.HasIndex(e => e.Status);
                entity.HasIndex(e => e.Priority);
                entity.HasIndex(e => e.CreatedAt);
                entity.HasIndex(e => e.SystemNumber);
            });

            // Batch configuration
            modelBuilder.Entity<Batch>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.PCID).IsRequired().HasMaxLength(50);
                entity.Property(e => e.FormulaName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Status).IsRequired();
                entity.Property(e => e.CreatedAt).IsRequired();
                entity.Property(e => e.CreatedByUserName).HasMaxLength(50);
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.Property(e => e.Units).HasMaxLength(50);
                entity.Property(e => e.Notes).HasMaxLength(500);
                
                // Indexes
                entity.HasIndex(e => e.PCID).IsUnique();
                entity.HasIndex(e => e.Status);
                entity.HasIndex(e => e.CreatedAt);
                entity.HasIndex(e => e.SystemNumber);
            });

            // Tank configuration
            modelBuilder.Entity<Tank>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(50);
                entity.Property(e => e.TankNumber).IsRequired();
                entity.Property(e => e.SystemNumber).IsRequired();
                entity.Property(e => e.Status).IsRequired();
                entity.Property(e => e.Capacity).IsRequired();
                entity.Property(e => e.CurrentLevel).IsRequired();
                entity.Property(e => e.Temperature).IsRequired();
                entity.Property(e => e.Viscosity).IsRequired();
                entity.Property(e => e.Material).HasMaxLength(100);
                entity.Property(e => e.Units).HasMaxLength(50);
                entity.Property(e => e.IsAgitatorRunning).IsRequired();
                entity.Property(e => e.IsHeatingEnabled).IsRequired();
                entity.Property(e => e.IsDischargeValveOpen).IsRequired();
                entity.Property(e => e.IsFillValveOpen).IsRequired();
                entity.Property(e => e.LastUpdated).IsRequired();
                entity.Property(e => e.Notes).HasMaxLength(500);
                
                // Indexes
                entity.HasIndex(e => e.TankNumber);
                entity.HasIndex(e => e.SystemNumber);
                entity.HasIndex(e => e.Status);
            });

            // Seed data
            SeedData(modelBuilder);
        }

        private void SeedData(ModelBuilder modelBuilder)
        {
            // Seed default users
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    Username = "operator1",
                    PasswordHash = "demo", // In production, use proper hashing
                    Level = UserLevel.Operator1,
                    SystemNumber = 1,
                    UserNumber = 1,
                    FullName = "Operator 1",
                    IsEnabled = true,
                    CreatedAt = DateTime.UtcNow
                },
                new User
                {
                    Id = 2,
                    Username = "supervisor1",
                    PasswordHash = "demo", // In production, use proper hashing
                    Level = UserLevel.Supervisor1,
                    SystemNumber = 1,
                    UserNumber = 2,
                    FullName = "Supervisor 1",
                    IsEnabled = true,
                    CreatedAt = DateTime.UtcNow
                },
                new User
                {
                    Id = 3,
                    Username = "ringwood",
                    PasswordHash = "demo", // In production, use proper hashing
                    Level = UserLevel.Ringwood,
                    SystemNumber = 1,
                    UserNumber = 3,
                    FullName = "Ringwood Admin",
                    IsEnabled = true,
                    CreatedAt = DateTime.UtcNow
                }
            );

            // Seed default tanks
            modelBuilder.Entity<Tank>().HasData(
                new Tank
                {
                    Id = 1,
                    Name = "Tank 1",
                    TankNumber = 1,
                    SystemNumber = 1,
                    Status = TankStatus.Empty,
                    Capacity = 1000,
                    CurrentLevel = 0,
                    Temperature = 25.0m,
                    Viscosity = 1.0m,
                    Material = "Water",
                    Units = "Gallons",
                    IsAgitatorRunning = false,
                    IsHeatingEnabled = false,
                    IsDischargeValveOpen = false,
                    IsFillValveOpen = false,
                    LastUpdated = DateTime.UtcNow
                },
                new Tank
                {
                    Id = 2,
                    Name = "Tank 2",
                    TankNumber = 2,
                    SystemNumber = 1,
                    Status = TankStatus.Empty,
                    Capacity = 1000,
                    CurrentLevel = 0,
                    Temperature = 25.0m,
                    Viscosity = 1.0m,
                    Material = "Water",
                    Units = "Gallons",
                    IsAgitatorRunning = false,
                    IsHeatingEnabled = false,
                    IsDischargeValveOpen = false,
                    IsFillValveOpen = false,
                    LastUpdated = DateTime.UtcNow
                }
            );
        }
    }
}
