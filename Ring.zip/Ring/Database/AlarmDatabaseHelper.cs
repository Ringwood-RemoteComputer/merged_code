﻿using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;


namespace Ring.Database
{
    public static class AlarmDatabaseHelper
    {
        private static readonly string _connStr = "Data Source=alarms.db";

        public static void CreateTable()
        {
            using (var conn = new SqliteConnection(_connStr))
            {
                conn.Open();

                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
                        CREATE TABLE IF NOT EXISTS Alarm (
                            ALMID INTEGER PRIMARY KEY AUTOINCREMENT,
                            ALMNUMBER INTEGER,
                            ALMTIME TEXT,
                            ALMDATE TEXT,   
                            ACKTIME TEXT,
                            ACKDATE TEXT,
                            ALMTYPENUMBER INTEGER,
                            ALMSTATUSNUMBER INTEGER,
                            ALMIDTYPE INTEGER,
                            ALMNAME TEXT
                        );
                    ";
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void Insert(AlarmRecord record)
        {
            using (var conn = new SqliteConnection(_connStr))
            {
                conn.Open();

                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
                        INSERT INTO Alarm (
                            ALMNUMBER, ALMTIME, ALMDATE,
                            ACKTIME, ACKDATE,
                            ALMTYPENUMBER, ALMSTATUSNUMBER,
                            ALMIDTYPE, ALMNAME
                        ) VALUES (
                            $number, $time, $date,
                            $ackTime, $ackDate,
                            $typeNum, $statusNum, $idType, $name
                        );
                    ";

                    cmd.Parameters.AddWithValue("$number", record.ALMNUMBER);
                    cmd.Parameters.AddWithValue("$time", record.ALMTIME);
                    cmd.Parameters.AddWithValue("$date", record.ALMDATE);
                    cmd.Parameters.AddWithValue("$ackTime", record.ACKTIME);
                    cmd.Parameters.AddWithValue("$ackDate", record.ACKDATE);
                    cmd.Parameters.AddWithValue("$typeNum", record.ALMTYPENUMBER);
                    cmd.Parameters.AddWithValue("$statusNum", record.ALMSTATUSNUMBER);
                    cmd.Parameters.AddWithValue("$idType", record.ALMIDTYPE);
                    cmd.Parameters.AddWithValue("$name", record.ALMNAME);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static List<AlarmRecord> GetAll()
        {
            var alarms = new List<AlarmRecord>();

            using (var conn = new SqliteConnection(_connStr))
            {
                conn.Open();

                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT * FROM Alarm ORDER BY ALMID DESC";

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            alarms.Add(new AlarmRecord
                            {
                                ALMID = reader.GetInt32(0),
                                ALMNUMBER = reader.GetInt32(1),
                                ALMTIME = reader.GetString(2),
                                ALMDATE = reader.GetString(3),
                                ACKTIME = reader.GetString(4),
                                ACKDATE = reader.GetString(5),
                                ALMTYPENUMBER = reader.GetInt32(6),
                                ALMSTATUSNUMBER = reader.GetInt32(7),
                                ALMIDTYPE = reader.GetInt32(8),
                                ALMNAME = reader.GetString(9)
                            });
                        }
                    }
                }
            }

            return alarms;
        }
    }
}
