﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using libplctag;
using libplctag.DataTypes.Simple;

namespace Ring.Services.PLC
{
    public class PlcTagReader
    {
        private readonly string _tagName;
        private readonly string _ip;
        private readonly string _path;
        private readonly PlcDataType _type;

        public PlcTagReader(string tagName, string ip, PlcDataType type, string path = "1,0")
        {
            _tagName = tagName;
            _ip = ip;
            _path = path;
            _type = type;
        }

        public string Read()
        {
            try
            {
                switch (_type)
                {
                    case PlcDataType.BOOL:
                        var tagBool = new TagBool()
                        {
                            Name = _tagName,
                            Gateway = _ip,
                            Path = _path,
                            PlcType = PlcType.ControlLogix,
                            Protocol = Protocol.ab_eip
                        };
                        return tagBool.Read() ? "True" : "False";

                    case PlcDataType.DINT:
                        var tagDint = new TagDint()
                        {
                            Name = _tagName,
                            Gateway = _ip,
                            Path = _path,
                            PlcType = PlcType.ControlLogix,
                            Protocol = Protocol.ab_eip
                        };
                        return tagDint.Read().ToString();

                    case PlcDataType.REAL:
                        var tagReal = new TagReal()
                        {
                            Name = _tagName,
                            Gateway = _ip,
                            Path = _path,
                            PlcType = PlcType.ControlLogix,
                            Protocol = Protocol.ab_eip
                        };
                        return tagReal.Read().ToString("0.###");

                    default:
                        return "Unsupported type";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Read error from {_tagName}: {ex.Message}");
                return "Error";
            }
        }
    }
}
