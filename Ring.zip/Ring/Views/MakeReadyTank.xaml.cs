﻿using System.Windows;

namespace Ring
{
    public partial class MakeReadyTank : Window
    {
        public MakeReadyTank()
        {
            InitializeComponent();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
