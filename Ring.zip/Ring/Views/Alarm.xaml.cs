﻿using System.Collections.Generic;
using System.Windows;

namespace Ring
{
    public partial class AlarmWindow : Window
    {
        public AlarmWindow()
        {
            InitializeComponent();

            // Populate DataGrid with sample data
            var alarms = new List<Alarm>
            {
                new Alarm { Type = "Warning", Status = "Active", AlarmNumber = 101, AlarmDescription = "Low Pressure", AlarmDate = "01/15/2025", AlarmTime = "14:30", AcknowledgeDate = "", AcknowledgeTime = "" },
                new Alarm { Type = "Critical", Status = "Acknowledged", AlarmNumber = 102, AlarmDescription = "High Temperature", AlarmDate = "01/14/2025", AlarmTime = "10:15", AcknowledgeDate = "01/14/2025", AcknowledgeTime = "10:20" }
            };

            AlarmDataGrid.ItemsSource = alarms;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }

    public class Alarm
    {
        public string Type { get; set; }
        public string Status { get; set; }
        public int AlarmNumber { get; set; }
        public string AlarmDescription { get; set; }
        public string AlarmDate { get; set; }
        public string AlarmTime { get; set; }
        public string AcknowledgeDate { get; set; }
        public string AcknowledgeTime { get; set; }
    }
}
