﻿using System;
using System.Windows;
using Ring.Database;
using Ring.Services.PLC;


namespace Ring
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Event handlers for the title bar buttons
        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Maximize_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = this.WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        // Event handlers for Menu Items

        private void Report_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Report clicked.");
        }

        private void TVCControl_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("TVC Control clicked.");
        }

        private void Hold_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Hold clicked.");
        }

        private void BatchStart_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Batch Start clicked.");
        }

        private void Shifts_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Shifts clicked.");
        }

        private void Setup_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Setup clicked.");
        }

        private void Window_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Window clicked.");
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Help clicked.");
        }
        private void Alarms_Click(object sender, RoutedEventArgs e)
        {
            var alarmWindow = new AlarmWindow();
            alarmWindow.ShowDialog(); // Opens the AlarmWindow as a modal dialog
        }
        private void MainScreen_Click(object sender, RoutedEventArgs e)
        {
            var makeReadyTankWindow = new MakeReadyTank();
            makeReadyTankWindow.ShowDialog(); // Opens the window as a modal dialog
        }
        private void BatchReport_Click(object sender, RoutedEventArgs e)
        {
            var batchReportWindow = new BatchReportWindow();
            batchReportWindow.ShowDialog(); // Opens the window as a modal dialog
        }
        private void TVCStorageTank1_Click(object sender, RoutedEventArgs e)
        {
            var tvcstorageTank1Window = new TVCStorageTank1Window();
            tvcstorageTank1Window.ShowDialog(); // Opens the window as a modal dialog
        }

        private void UsageReport_Click(object sender, RoutedEventArgs e)
        {
            var usageReportWindow = new UsageReportWindow();
            usageReportWindow.ShowDialog(); // Opens the Usage Report window as a modal dialog
        }

        private void AlarmHistory_Click(object sender, RoutedEventArgs e)
        {
            var alarmHistoryWindow = new AlarmHistory();
            alarmHistoryWindow.ShowDialog(); // Opens the Usage Report window as a modal dialog
        }

        private void ShiftControl_Click(object sender, RoutedEventArgs e)
        {
            var shiftWindow = new ShiftControlWindow();
            shiftWindow.ShowDialog();
        }
        private void BatchStorageTank1_Click(object sender, RoutedEventArgs e)
        {
            var batchstorageTank1Window = new BatchStorageTank1();
            batchstorageTank1Window.ShowDialog(); // Opens the window as a modal dialog
        }

        private void ReadTags_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var boolReader = new PlcTagReader("Alarm_ons1", "192.168.202.10", PlcDataType.BOOL);
                BoolTagValue.Text = $"BOOL Tag: {boolReader.Read()}";

                var dintReader = new PlcTagReader("Alarm_block", "192.168.202.10", PlcDataType.DINT);
                DintTagValue.Text = $"DINT Tag: {dintReader.Read()}";

                //var realReader = new PlcTagReader("PC_Read_Float[1]", "192.168.202.10", PlcDataType.REAL);
                //RealTagValue.Text = $"REAL Tag: {realReader.Read()}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to read from PLC: {ex.Message}", "PLC Read Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        //private void ReadTags_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        var now = DateTime.Now;

        //        bool simulatedBool = new Random().Next(0, 2) == 1;
        //        int simulatedDint = new Random().Next(100, 999);

        //        BoolTagValue.Text = $"Simulated BOOL Tag: {simulatedBool}";
        //        DintTagValue.Text = $"Simulated DINT Tag: {simulatedDint}";

        //        if (simulatedBool)
        //        {
        //            var alarm = new AlarmRecord
        //            {
        //                ALMNUMBER = new Random().Next(1000, 9999),
        //                ALMTIME = now.ToString("HH:mm:ss"),
        //                ALMDATE = now.ToString("yyyy-MM-dd"),
        //                ACKTIME = now.AddMinutes(1).ToString("HH:mm:ss"),
        //                ACKDATE = now.AddMinutes(1).ToString("yyyy-MM-dd"),
        //                ALMTYPENUMBER = 1,
        //                ALMSTATUSNUMBER = simulatedDint,
        //                ALMIDTYPE = 101,
        //                ALMNAME = "Simulated Alarm from Fake PLC"
        //            };

        //            Ring.Database.AlarmDatabaseHelper.Insert(alarm);
        //            LoadAlarmData(); // 👈 Refresh DataGrid after inserting
        //            MessageBox.Show("Simulated Alarm Logged to SQLite.");
        //        }
        //        else
        //        {
        //            MessageBox.Show("No alarm condition. Simulated BOOL is false.");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show($"Simulated PLC Read Failed: {ex.Message}");
        //    }
        //}

        private void LoadAlarmData()
        {
            AlarmDataGrid.ItemsSource = Ring.Database.AlarmDatabaseHelper.GetAll();
        }
    }

    //    private void WriteToPlc()
    //    {
    //        var boolWriter = new PlcTagWriter("PC_Display_Outputs[0]", "192.168.1.20", PlcDataType.BOOL);
    //        boolWriter.Write("true");

    //        // Write to a DINT tag
    //        var intWriter = new PlcTagWriter("BatchID", "192.168.1.20", PlcDataType.DINT);
    //        intWriter.Write("42");

    //        // Write to a REAL tag
    //        var floatWriter = new PlcTagWriter("TankTemp", "192.168.1.20", PlcDataType.REAL);
    //        floatWriter.Write("78.65");

    //    }

}