using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using Ring.Services.Images;

namespace Ring
{
    public partial class SplashScreen : Window
    {
        private readonly ImageStateManager _imageStateManager;
        private readonly Action<string> _updateStatus;
        private readonly Action<double> _updateProgress;

        public SplashScreen()
        {
            InitializeComponent();
            
            _updateStatus = (status) => Dispatcher.Invoke(() => StatusText.Text = status);
            _updateProgress = (progress) => Dispatcher.Invoke(() => ProgressBar.Value = progress);
            
            _imageStateManager = new ImageStateManager(OnImageChanged);
            
            Loaded += SplashScreen_Loaded;
        }

        private void SplashScreen_Loaded(object sender, RoutedEventArgs e)
        {
            _ = InitializeSystemAsync();
        }

        private async Task InitializeSystemAsync()
        {
            try
            {
                _updateStatus("Initializing system...");
                _updateProgress(10);
                await Task.Delay(500);

                _updateStatus("Loading configuration...");
                _updateProgress(20);
                await Task.Delay(500);

                _updateStatus("Connecting to database...");
                _updateProgress(30);
                await Task.Delay(500);

                _updateStatus("Initializing PLC communication...");
                _updateProgress(50);
                await Task.Delay(500);

                _updateStatus("Loading image resources...");
                _updateProgress(70);
                await Task.Delay(500);

                _updateStatus("Starting services...");
                _updateProgress(90);
                await Task.Delay(500);

                _updateStatus("System ready");
                _updateProgress(100);
                await Task.Delay(1000);

                // Close splash screen and open main window
                var mainWindow = new MainWindow();
                mainWindow.Show();
                Close();
            }
            catch (Exception ex)
            {
                _updateStatus($"Error: {ex.Message}");
                await Task.Delay(3000);
                Application.Current.Shutdown();
            }
        }

        private void OnImageChanged(string imageName, BitmapImage image)
        {
            Dispatcher.Invoke(() =>
            {
                switch (imageName.ToLower())
                {
                    case "splash left.png":
                        LeftImage.Source = image;
                        break;
                    case "splash center.png":
                        CenterImage.Source = image;
                        break;
                    case "splash right.png":
                        RightImage.Source = image;
                        break;
                }
            });
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Allow clicking to close splash screen
            Close();
        }
    }
}
