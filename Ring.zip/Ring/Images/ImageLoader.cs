﻿// Ring/Services/Images/ImageLoader.cs
using System;
using System.IO;
using System.Windows.Media.Imaging;

namespace Ring.Services.Images
{
    public class ImageLoader
    {
        private static readonly string ImagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images");

        public static BitmapImage LoadImage(string imageName)
        {
            try
            {
                var imagePath = Path.Combine(ImagePath, imageName);
                if (File.Exists(imagePath))
                {
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                    bitmap.UriSource = new Uri(imagePath);
                    bitmap.EndInit();
                    return bitmap;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading image {imageName}: {ex.Message}");
            }

            return CreateErrorImage();
        }

        private static BitmapImage CreateErrorImage()
        {
            // Create a simple error pattern
            var bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.UriSource = new Uri("pack://application:,,,/Images/error.png");
            bitmap.EndInit();
            return bitmap;
        }

        public static BitmapImage LoadStateImage(string baseImageName, string state)
        {
            var stateImageName = $"{baseImageName}_{state}.png";
            return LoadImage(stateImageName);
        }
    }
}