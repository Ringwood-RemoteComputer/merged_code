using System;
using System.ComponentModel.DataAnnotations;

namespace Ring.Models
{
    /// <summary>
    /// Tank status
    /// </summary>
    public enum TankStatus
    {
        Empty = 0,
        Filling = 1,
        Full = 2,
        Discharging = 3,
        Maintenance = 4,
        Offline = 5
    }

    /// <summary>
    /// Tank entity for storage tank management
    /// </summary>
    public class Tank
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; } = string.Empty;

        [Required]
        public int TankNumber { get; set; }

        [Required]
        public int SystemNumber { get; set; }

        [Required]
        public TankStatus Status { get; set; }

        [Required]
        public decimal Capacity { get; set; }

        [Required]
        public decimal CurrentLevel { get; set; }

        [Required]
        public decimal Temperature { get; set; }

        [Required]
        public decimal Viscosity { get; set; }

        [MaxLength(100)]
        public string? Material { get; set; }

        [MaxLength(50)]
        public string? Units { get; set; }

        public bool IsAgitatorRunning { get; set; } = false;

        public bool IsHeatingEnabled { get; set; } = false;

        public bool IsDischargeValveOpen { get; set; } = false;

        public bool IsFillValveOpen { get; set; } = false;

        public decimal? SetpointTemperature { get; set; }

        public decimal? SetpointLevel { get; set; }

        public DateTime LastUpdated { get; set; } = DateTime.UtcNow;

        [MaxLength(500)]
        public string? Notes { get; set; }

        public bool IsOnline => Status != TankStatus.Offline;

        public bool IsEmpty => CurrentLevel <= 0;

        public bool IsFull => CurrentLevel >= Capacity;

        public decimal FillPercentage => Capacity > 0 ? (CurrentLevel / Capacity) * 100 : 0;

        /// <summary>
        /// Update tank level
        /// </summary>
        public void UpdateLevel(decimal newLevel)
        {
            CurrentLevel = Math.Max(0, Math.Min(newLevel, Capacity));
            LastUpdated = DateTime.UtcNow;

            // Update status based on level
            if (CurrentLevel <= 0)
                Status = TankStatus.Empty;
            else if (CurrentLevel >= Capacity)
                Status = TankStatus.Full;
            else if (Status == TankStatus.Empty)
                Status = TankStatus.Filling;
        }

        /// <summary>
        /// Update temperature
        /// </summary>
        public void UpdateTemperature(decimal newTemperature)
        {
            Temperature = newTemperature;
            LastUpdated = DateTime.UtcNow;
        }

        /// <summary>
        /// Update viscosity
        /// </summary>
        public void UpdateViscosity(decimal newViscosity)
        {
            Viscosity = newViscosity;
            LastUpdated = DateTime.UtcNow;
        }

        /// <summary>
        /// Start agitator
        /// </summary>
        public void StartAgitator()
        {
            IsAgitatorRunning = true;
            LastUpdated = DateTime.UtcNow;
        }

        /// <summary>
        /// Stop agitator
        /// </summary>
        public void StopAgitator()
        {
            IsAgitatorRunning = false;
            LastUpdated = DateTime.UtcNow;
        }

        /// <summary>
        /// Enable heating
        /// </summary>
        public void EnableHeating()
        {
            IsHeatingEnabled = true;
            LastUpdated = DateTime.UtcNow;
        }

        /// <summary>
        /// Disable heating
        /// </summary>
        public void DisableHeating()
        {
            IsHeatingEnabled = false;
            LastUpdated = DateTime.UtcNow;
        }

        /// <summary>
        /// Open discharge valve
        /// </summary>
        public void OpenDischargeValve()
        {
            IsDischargeValveOpen = true;
            if (Status == TankStatus.Full)
                Status = TankStatus.Discharging;
            LastUpdated = DateTime.UtcNow;
        }

        /// <summary>
        /// Close discharge valve
        /// </summary>
        public void CloseDischargeValve()
        {
            IsDischargeValveOpen = false;
            if (Status == TankStatus.Discharging)
                Status = TankStatus.Full;
            LastUpdated = DateTime.UtcNow;
        }

        /// <summary>
        /// Open fill valve
        /// </summary>
        public void OpenFillValve()
        {
            IsFillValveOpen = true;
            if (Status == TankStatus.Empty)
                Status = TankStatus.Filling;
            LastUpdated = DateTime.UtcNow;
        }

        /// <summary>
        /// Close fill valve
        /// </summary>
        public void CloseFillValve()
        {
            IsFillValveOpen = false;
            if (Status == TankStatus.Filling)
                Status = TankStatus.Full;
            LastUpdated = DateTime.UtcNow;
        }
    }
}
