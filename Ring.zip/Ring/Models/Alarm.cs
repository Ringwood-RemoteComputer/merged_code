using System;
using System.ComponentModel.DataAnnotations;

namespace Ring.Models
{
    /// <summary>
    /// Alarm priority levels
    /// </summary>
    public enum AlarmPriority
    {
        Low = 1,
        Medium = 2,
        High = 3,
        Critical = 4
    }

    /// <summary>
    /// Alarm status
    /// </summary>
    public enum AlarmStatus
    {
        Active = 0,
        Acknowledged = 1,
        Cleared = 2,
        Suppressed = 3
    }

    /// <summary>
    /// Alarm types
    /// </summary>
    public enum AlarmType
    {
        System = 0,
        Process = 1,
        Safety = 2,
        Maintenance = 3,
        Communication = 4
    }

    /// <summary>
    /// Alarm entity for industrial alarm management
    /// </summary>
    public class Alarm
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string TagName { get; set; } = string.Empty;

        [Required]
        [MaxLength(200)]
        public string Description { get; set; } = string.Empty;

        [Required]
        public AlarmPriority Priority { get; set; }

        [Required]
        public AlarmType Type { get; set; }

        [Required]
        public AlarmStatus Status { get; set; }

        [Required]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? AcknowledgedAt { get; set; }

        public DateTime? ClearedAt { get; set; }

        public int? AcknowledgedByUserId { get; set; }

        [MaxLength(50)]
        public string? AcknowledgedByUserName { get; set; }

        public int? SystemNumber { get; set; }

        public int? TankNumber { get; set; }

        [MaxLength(100)]
        public string? Value { get; set; }

        [MaxLength(100)]
        public string? Setpoint { get; set; }

        [MaxLength(100)]
        public string? Units { get; set; }

        [MaxLength(500)]
        public string? AdditionalInfo { get; set; }

        public bool IsActive => Status == AlarmStatus.Active;

        public bool IsAcknowledged => Status == AlarmStatus.Acknowledged;

        public bool IsCleared => Status == AlarmStatus.Cleared;

        /// <summary>
        /// Acknowledge the alarm
        /// </summary>
        public void Acknowledge(int userId, string userName)
        {
            if (Status == AlarmStatus.Active)
            {
                Status = AlarmStatus.Acknowledged;
                AcknowledgedAt = DateTime.UtcNow;
                AcknowledgedByUserId = userId;
                AcknowledgedByUserName = userName;
            }
        }

        /// <summary>
        /// Clear the alarm
        /// </summary>
        public void Clear()
        {
            if (Status == AlarmStatus.Acknowledged)
            {
                Status = AlarmStatus.Cleared;
                ClearedAt = DateTime.UtcNow;
            }
        }

        /// <summary>
        /// Suppress the alarm
        /// </summary>
        public void Suppress()
        {
            Status = AlarmStatus.Suppressed;
        }

        /// <summary>
        /// Get alarm duration
        /// </summary>
        public TimeSpan GetDuration()
        {
            var endTime = ClearedAt ?? DateTime.UtcNow;
            return endTime - CreatedAt;
        }
    }
}
